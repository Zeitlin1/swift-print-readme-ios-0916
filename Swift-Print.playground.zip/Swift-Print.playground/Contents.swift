var favoriteWord = "Formidable"

var favoriteColor = "Blue"

var favoriteMusician = "Led Zepplin"

print(favoriteWord)
print(favoriteColor)
print(favoriteMusician)

print("I'm printing a string in Swift!")

print("my favorite color is \(favoriteColor), my favorie word is \(favoriteWord), and my favorite musician is \(favoriteMusician)!")

var skySentence = "The color of the sky is \(favoriteColor)"

print(skySentence)


